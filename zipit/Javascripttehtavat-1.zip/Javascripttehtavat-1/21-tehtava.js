const radius = 4;
const pi = Math.PI;
function areaOfCircle (radius, pi) {
    return pi * (radius ^2)
}

console.log ("The area of the circle is " + areaOfCircle(radius, pi));