let i = 1;
let j = 0;

length = 5;

for (let index = 0; index < length; index++) {
    console.log (i + " potenssiin " + j + " = " + Math.pow(i, j))
    i++;
    j++;
}